# Repositório de Estudos - Java Orientado a Objetos

Este repositório reúne anotações, exercícios e projetos pessoais do Maicon Reformed para estudar programação orientada a objetos com Java, além de práticas aplicadas no desenvolvimento de um app Android.

## Estrutura

### 📚 /teoria
PDFs com conceitos de:
- Classe vs Objeto
- Membros de Classe
- Palavra-chave `this`
- Valor vs Referência

### 🧪 /praticas/PessoaEndereco
Exercício de composição entre classes:
- `Pessoa` tem um `Endereco`
- Exibição formatada de dados no console

### 📱 /app-android
Base para o aplicativo Android gamificado (em desenvolvimento)

---

## Autor
**Maicon Emanuel (Maicon Reformed)**  
Estudante e desenvolvedor Java em formação.
