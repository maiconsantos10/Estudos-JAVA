package praticas.PessoaEndereco;

public class Main {
    public static void main(String[] args) {
        Endereco endereco = new Endereco("Rua Bangu", 257, "Rio de Janeiro");
        Pessoa pessoa = new Pessoa("Maicon", 25, endereco);
        pessoa.exibirInformacoes();
    }
}
